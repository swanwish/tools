#!/bin/bash

set -e

# Set IFS to only newline character to handle file names with spaces
IFS=$'\n'

for file in $(find . -type f \( -iname "*.mp3" -o -iname "*.wav" -o -iname "*.aac" -o -iname "*.flac" -o -iname "*.m4a" \)); do
  dir=$(dirname $file)
  src=$(basename $file)
  base="${src%.*}"
  dest="${base}.mp3"
  echo "The base is ${base} and dest is ${dest}"

  # Check whether the file start with "_", if true, then skip this file
  if [[ ${src} == _* ]]; then
    echo "Skip file ${src}"
    continue
  fi

  # Check the target exists or not
  target="${dir}/_${dest}"
  if [ -f $target ]; then
    echo "The file ${target} already exists"
    continue
  fi

  # Convert file to mp3 file
  echo "Convert file ${file}"
  ffmpeg -i "${file}" -c:a libmp3lame -q:a 7  "${target}"
done
